from time import sleep
from subprocess import Popen
from tempfile import TemporaryFile

UNSCORED = 0
SCORED = 1
PENALTY = 2
INVALID = 3

class ConfigObject:
    path = ""
    key = ""
    entry = ""
    delim = ""
    keyFound = False
    points = 0
    comment = None
    def check(t):
        if not t.path == "" and not t.key == "" and not t.entry == "" and not t.delim == "":
            f = open( t.path, 'r+' )
            for line in f.readlines():
                checker = line.split( t.delim )
                t.keyFound = False
                for part in checker:
                    newPart = part.replace(" ", "")
                    newPart = newPart.replace('\n', "")
                    newPart = newPart.replace('\r', "")
                    t.keyFound = t.keyFound or ( newPart == t.key )
                    if t.keyFound:
                        if newPart == t.entry:
                            f.close()
                            return (1, t.points, t.comment)
            f.close()
            return (0, t.points, t.comment)
        else:
            print "Object not properly instantiated."
            return (3, t.points, t.comment)

class UserObject:
    username = ""
    password = ""
    exist = None
    changePw = None
    correct = False
    points = 0
    comment = None
    def check(t):
        f = open( "/etc/passwd", 'r+' )
        if not t.exist == None:
            if t.exist:        
                for userLine in f.readlines():
                    user = userLine.split( ':' )
                    if user[0] == t.username:   
                        if t.changePw:
                            f.close()
                            f = open( "/etc/shadow", 'r+' )
                            for userLine in f.readlines():
                                user = userLine.split( ':' )
                                if user[0] == t.username and not user[1] == t.password:
                                    f.close()
                                    return (1, t.points, t.comment)
                            f.close()
                            return (0, t.points, t.comment)
                        else:
                            f.close()
                            return (1, t.points, t.comment)
                f.close()
                return (2, points, comment)
            else:
                for userLine in f.readlines():
                    user = userLine.split( ':' )
                    if user[0] == t.username:
                        f.close()
                        return (0, t.points, t.comment)
                return (1, t.points, t.comment)
        else:
            for userLine in f.readlines():
                user = userLine.split( ':' )
                if user[0] == t.username:
                    f.close()
                    return (1, t.points, t.comment)
            f.close()
            return (0, t.points, t.comment)

class MemberObject:
    groupname = ""
    username = ""
    authorized = None
    points = 0
    comment = ""
    def check(t):
        if not t.authorized == None:
            f = open( "/etc/group", 'r+' )
            for groupLine in f.readlines():
                group = groupLine.split( ':' )
                if group[0] == t.groupname:
                    memberStr = group[3]
                    memberStr = memberStr.replace( ' ', '' )
                    memberStr = memberStr.replace('\r', "")
                    memberStr = memberStr.replace('\n', "")
                    memberList = memberStr.split( ',' )
                    if ( memberList.count( t.username ) > 0 ) == t.authorized:
                        f.close()
                        return ( 1, t.points, t.comment )
                    else:
                        f.close()
                        return ( 0, t.points, t.comment )
            return ( 0, t.points, t.comment ) 
        else:
            return (3, t.points, t.comment)

class CommandObject:
	command = ""
	output = ""
	expected = None
	points = 0
	comment = ""
	def check(t):
		if not t.expected == None:
			with TemporaryFile() as output:
				cmd = Popen( t.command, stdout = output, shell=True )
				cmd.wait()
				output.seek( 0 )
				if ( output.read().find( t.output ) >= 0 ) == t.expected:
					return ( 1, t.points, t.comment )
				else:
					return ( 0, t.points, t.comment )
		else:
			return ( 3, t.points, t.commment )

def newConfigObject( path, key, entry, delim, points, comment="" ):
    confObj = ConfigObject()
    confObj.path = path
    confObj.key = key
    confObj.entry = entry
    confObj.delim = delim
    confObj.points = points
    confObj.comment = comment
    return confObj

def newUserObject( username, exist, changePw, password, points, comment="" ):
    userObj = UserObject()
    userObj.username = username
    userObj.exist = exist
    userObj.changePw = changePw
    userObj.password = password
    userObj.points = points
    userObj.comment = comment
    return userObj

def newMemberObject( groupname, username, authorized, points, comment="" ):
    membObj = MemberObject()
    membObj.groupname = groupname
    membObj.username = username
    membObj.authorized = authorized
    membObj.points = points
    membObj.comment = comment
    return membObj

def newCommandObject( command, output, expected, points, comment="" ):
 	cmdObj = CommandObject()
 	cmdObj.command = command
 	cmdObj.output = output
 	cmdObj.expected = expected
 	cmdObj.points = points
 	cmdObj.comment = comment
 	return cmdObj

def writeScores(imageName, vulnLines, totalPoints, currentVulns, totalVulns):
    with open('/var/opt/CyberSec/Template.html', 'r') as input_file, open('/var/opt/CyberSec/ScoringReport.html', 'w') as output_file:
        for line in input_file:
            if line.strip() == '{{LIST}}':
                for vulnLine in vulnLines:
                    output_file.write(vulnLine)
            else:
                newLine = line
                newLine = newLine.replace( "{{IMAGENAME}}", imageName )
                newLine = newLine.replace( "{{POINTS}}", str( totalPoints ) )
                newLine = newLine.replace( "{{CURRENT}}", str( currentVulns ) )
                newLine = newLine.replace( "{{VULNS}}", str( totalVulns ) )
                output_file.write(newLine)

vulns = []
vulns.append( newConfigObject( "/etc/lightdm/lightdm.conf", "allow-guest", "false", "=", 2, "Guest account is disabled" ) )
vulns.append( newUserObject( "vector", False, None, None, 2, "Removed unauthorized user vector" ) )
vulns.append( newUserObject( "short", False, None, None, 2, "Removed unauthorized user short" ) )
vulns.append( newUserObject( "telnet", False, None, None, 3, "Removed hidden user telnet" ) )
vulns.append( newMemberObject( "sudo", "aaron", False, 2, "User aaron is not an administrator" ) )
vulns.append( newMemberObject( "sudo", "nicole", False, 2, "User nicole is not an administrator" ) )
vulns.append( newUserObject( "root", True, True, "", 2, "Changed insecure root password" ) )
vulns.append( newConfigObject( "/etc/pam.d/common-password", "password", "remember=10", " ", 4, "Previous passwords are remembered" ) )
vulns.append( newConfigObject( "/etc/pam.d/common-password", "password", "sha512", " ", 4, "A secure password hashing algorithm is used" ) )
vulns.append( newConfigObject( "/etc/login.defs", "PASS_MAX_DAYS", "15", '\t', 4, "A default maxiumum password age is set" ) )
vulns.append( newConfigObject( "/etc/pam.d/common-auth", "auth", "deny=10", " ", 4, "An account lockout policy is configured" ) )
vulns.append( newConfigObject( "/etc/sysctl.conf", "net.ipv4.conf.all.rp_filter", "1", "=", 4, "IPv4 source route verification enabled" ) )
vulns.append( newConfigObject( "/etc/sysctl.conf", "net.ipv4.conf.all.send_redirects", "0", "=", 4, "IPv4 sending ICMP redirects disabled" ) )
vulns.append( newConfigObject( "/etc/sysctl.conf", "net.ipv4.tcp_synack_retries", "2", "=", 4, "IPv4 TCP SYN,ACK retries reduced" ) )
vulns.append( newCommandObject( "ufw status", "Status: active", True, 4, "Firewall protection has been enabled" ) )
vulns.append( newCommandObject( "service ssh status", "ssh start/running", True, 4, "sshd service has been installed and started" ) )
vulns.append( newCommandObject( "service apache2 status", "* apache2 is running", False, 4, "Apache2 service has been stopped and disabled" ) )
vulns.append( newCommandObject( "service inspircd status", "* inspircd is running", False, 4, "IRC daemon has been stopped and disabled" ) )
vulns.append( newCommandObject( "service mysql status", "Uptime:", False, 4, "MariaDB service has been stopped and disabled" ) )
vulns.append( newCommandObject( "find /home | grep [.]favorites", ".favorites", False, 3, "Prohibited MP3 files are removed" ) )
vulns.append( newCommandObject( "apt list --installed | grep firefox/", "upgradable", False, 3, "Firefox has been updated" ) )
vulns.append( newCommandObject( "apt list --installed | grep openssl", "upgradable", False, 3, "OpenSSL has been updated" ) )
vulns.append( newCommandObject( "apt list --installed | grep ophcrack/", "installed", False, 3, "Prohibited software ophcrack removed" ) )
vulns.append( newCommandObject( "apt list --installed | grep ettercap-common/", "installed", False, 3, "Prohibited software Ettercap removed" ) )
vulns.append( newCommandObject( "find /var | grep oxygen.html", "oxygen", False, 3, "Removed html file with credit card numbers in it" ) )
vulns.append( newCommandObject( "crontab -u root -l", "nc -e /bin/sh -nvlp 1337", False, 3, "Removed netcat backdoor" ) )
vulns.append( newCommandObject( "cat /etc/samba/smb.conf", "[share]", False, 3, "Public Samba Share is disabled" ) )
vulns.append( newCommandObject( "cat /etc/sudoers", "!authenticate", False, 4, "Insecure sudo configuration fixed" ) )
vulns.append( newCommandObject( "stat /var/opt/AFAGenesis/", "(0600/", True, 4, "Fixed insecure permissions for AFAGenesis" ) )
vulns.append( newConfigObject( "/etc/apt/apt.conf.d/10periodic", "APT::Periodic::Update-Package-Lists", "\"1\";", " ", 3, "The system automatically checks for updates daily" ) )
vulns.append( newConfigObject( "/etc/ssh/sshd_config", "PermitRootLogin", "no", " ", 2, "SSH root login has been disabled" ) )

def checkVuln( vuln ):
    return vuln.check()

lastPoints = 0
while True:
    vulnLines = []
    totalPoints = 0
    currentVulns = 0
    for vuln in vulns:
        data = checkVuln( vuln )
        if data[0] == 1:
            totalPoints += data[ 1 ]
            currentVulns += 1
            vulnLines.append( data[ 2 ] + " - " + str( data[ 1 ] ) + "<br>\n" )
    if totalPoints > lastPoints:
    	Popen( "aplay /var/opt/CyberSec/gain.wav".split(' ') )
    elif totalPoints < lastPoints:
    	Popen( "aplay /var/opt/CyberSec/alarm.wav".split(' ') )
    lastPoints = totalPoints
    writeScores( "CP-X JenniSys Practice Run", vulnLines, totalPoints, currentVulns, len( vulns ) )
    sleep(30)
