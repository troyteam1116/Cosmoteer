You work for a promising start-up company All-time Favorites Arcade which is internally referred 
to as AFA. Our game development department at AFA failed their latest security assessment. You have 
been assigned to help the development department improve their security posture.

A new company policy will allow developers to work at home 2 days a week. In order to facilitate 
this transition the OpenSSH server (sshd) should be installed and enabled on this computer. All 
authorized users (and administrators) should be able to log into this computer remotely using OpenSSH. 

This company's security policies require that all user accounts be password protected. The presence of 
any media files and hacking tools on any computers is strictly prohibited. This company currently 
does not use any centralized maintenance or polling tools to manage their IT equipment. This computer 
is for official business use only by authorized users.

It is company policy to use only Ubuntu 14.04 on this computer. Management has decided that the default 
web browser for all users on this computer should be the latest stable version of Firefox. Company policy 
is to never let users log in as root. If administrators need to run commands as root, they are required 
to use the sudo command.

All authorized users must be able to log in remotely using SSH. Therefore, sshd is a critical service and 
needs to remain enabled. This computer is also a file sharing server that uses samba. The purpose of 
this file server is to provide developers with anonymous, read-only access in order to download their 
favorite development tools such as 7zip, Eclipse, and Ninja-IDE. The path to the share is:
/var/opt/AFAGenesis

It is company policy to use only the latest stable Ubuntu 14.04 packages available for required software 
and services on this computer.

Critical Services:
sshd
samba

Authorized Administrators:

jen (you)
	Password: LifeIs00P!Java
fetus
	Password: Dev!@t10n
jino
	Password: TakeB@dAdv!ce
kanin
	Password: ItzC0ldOuss!de
khoa
	Password: S0hCahC0h!Ah
jay
	Password: $hady!mANDmS

Authorized Users:

charissa
brandon
silas
hayoung
christo
anke
jarred
zaogao
nicole
brendon
aaron

Do not remove any authorized users or their home directories.

You can view your current scoring report by double clicking on the CyberPatriot Scoring Report icon on the desktop

The timezone of this image is set to UTC, please do not change the timezone, the date, or the time on this image.
